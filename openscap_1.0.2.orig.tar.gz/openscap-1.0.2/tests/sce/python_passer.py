#!/usr/bin/env python

import os, sys

sys.exit(int(os.environ["XCCDF_RESULT_PASS"]))

