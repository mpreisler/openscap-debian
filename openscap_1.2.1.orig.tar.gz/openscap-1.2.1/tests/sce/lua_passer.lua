#!/usr/bin/env lua

os.exit(os.getenv("XCCDF_RESULT_PASS"))

